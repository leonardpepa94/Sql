-- Creazione Database per l'Azienda ToysGroup
CREATE DATABASE ToysGroup;
USE ToysGroup;

-- Creazione tabella Product
CREATE TABLE Product (
productid INT PRIMARY KEY NOT NULL,
productname VARCHAR(100),
category VARCHAR(50));

-- Creazione tabella Region
CREATE TABLE Region (
regionid INT PRIMARY KEY,
region_name VARCHAR(50),
state VARCHAR(25));

-- Creazione tabella Sales
CREATE TABLE Sales (
saleid INT PRIMARY KEY,
saledate DATE,
productid INT,
regionid INT,
quantity INT,
price DECIMAL(10,2),
FOREIGN KEY (productid) REFERENCES Product(productid),
FOREIGN KEY (regionid) REFERENCES Region(regionid));

-- Inserimento dati in Product
INSERT INTO Product (productid, productname, category) VALUES
(1,'Peluche Unicorno','Peluche'),
(2,'Baby Born','Fashion'),
(3,'Puzzle Power','Puzzle'),
(4,'Bike Retro','Bicycle'),
(5,'LeapFrog','Learnig'),
(6,'Lego Creator','Building');

-- Inserimento dati in Region 
INSERT INTO Region (regionid, region_name, state) VALUES
(1,'Lombardia','Italy'),
(2,'Île de France','France'),
(3,'Southern Kanto','Japan'),
(4,'Alta Baviera','Germany'),
(5,'East China','China'),
(6,'New York','United States');

-- Inserimento dati in Sales
INSERT INTO Sales (saleid, saledate, productid, regionid, quantity, price) VALUES
(1,'2024-04-20',1,1,150,20.90),
(2,'2024-04-21',3,2,105,30),
(3,'2024-04-22',2,4,80,19),
(4,'2024-04-23',5,3,170,40.90),
(5,'2024-04-24',6,6,200,50),
(6,'2024-04-25',4,6,90,140.50),
(7,'2024-04-26',5,5,80,45);


-- Verifica unicità productid (PRIMARY KEY) 
SELECT productid, count(productid) AS totale
FROM product
GROUP BY productid
HAVING totale>1
ORDER BY totale; -- Non devono comparire valori nella tabella quando eseguita, significa che non ci sono duplicati!

-- Verifica unicità regionid (PRIMARY KEY) 
SELECT regionid, count(regionid) AS totale
FROM region
GROUP BY regionid
HAVING totale>1
ORDER BY totale; -- Non devono comparire valori nella tabella quando eseguita, significa che non ci sono duplicati!

-- Verifica unicità saleid (PRIMARY KEY) 
SELECT saleid, count(saleid) AS totale
FROM sales
GROUP BY saleid
HAVING totale>1
ORDER BY totale; -- Non devono comparire valori nella tabella quando eseguita, significa che non ci sono duplicati!

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT p.productname, YEAR(s.saledate) AS yearlysales, SUM(s.quantity*s.price) as total
FROM product as p
INNER JOIN sales as s on p.productid=s.productid
GROUP BY p.productname, YEAR(s.saledate)
ORDER BY p.productname;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT r.state, YEAR(s.saledate) AS yearlysales, SUM(s.quantity*s.price) as total
FROM region as r
INNER JOIN sales as s on r.regionid=s.regionid
GROUP BY r.state, YEAR(s.saledate)
ORDER BY yearlysales, total DESC;

-- Qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT p.category, SUM(s.quantity) as totalquantity 
FROM product as p
INNER JOIN sales as s on p.productid=s.saleid
GROUP BY p.category
ORDER BY totalquantity DESC
LIMIT 1;

-- Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
SELECT productname
FROM product
WHERE productid NOT IN (SELECT productid FROM sales);

SELECT p.productname
FROM product as p
LEFT JOIN sales as s ON p.productid=s.productid
WHERE s.saleid IS NULL;

-- Elencare i prodotti secondo la rispettiva ultima data di vendita.
SELECT p.productname, MAX(s.saledate) AS lastsaledate
FROM product as p
INNER JOIN sales as s ON p.productid=s.productid
GROUP BY p.productname
ORDER BY p.productname;
